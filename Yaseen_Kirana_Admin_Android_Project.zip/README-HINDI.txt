YASEEN KIRANA ADMIN - ANDROID WRAPPER PROJECT

This Android app opens the existing Admin page:
https://mystore2.shahrukhkhan16805.workers.dev/admin/

It does not modify or redeploy the live website or database.
The customer app page is not used by this Android wrapper.

Build:
1. Upload the contents of this ZIP (not the ZIP itself) into the root of the separate YASEEN-STORE-ADMIN- GitHub repository.
2. Commit the files to the main branch.
3. Open Actions and select "Build Yaseen Kirana Admin APK".
4. Wait for the run to finish, then download the Yaseen-Kirana-Admin-APK artifact.
5. Extract the artifact ZIP and install app-debug.apk.

This is a debug APK for testing. Internet access is required. The app loads the live /admin/ route, so ensure that route is protected by proper admin authentication before sharing the APK.
